/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogos.ui;

import java.util.List;
import java.util.Vector;
import jogos.entity.Emprestimos;
import jogos.util.NovoHibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.QueryException;
import org.hibernate.Session;

/**
 *
 * @author Delquen
 */
public class GerenciaDados {
    
    private static String query = "from Emprestimos";
    
    public Vector executeHQLquery() {
                
        Vector tableData = new Vector();
        
        try {
            Session session = NovoHibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            Query q = session.createQuery(query);
            List resultList = q.list();
            
            for(Object o : resultList) {
            Emprestimos emprestimos = (Emprestimos)o;
            Vector<Object> oneRow = new Vector<Object>();
            oneRow.add(emprestimos.getId());
            oneRow.add(emprestimos.getNomeAmigo());
            oneRow.add(emprestimos.getEndereco());
            oneRow.add(emprestimos.getNomeJogo());
            if (emprestimos.getStatus() == 1)
                oneRow.add("Emprestado");
            else
                oneRow.add("Devolvido");
            oneRow.add(emprestimos.getTelefone());
            oneRow.add(emprestimos.getDataEmprestimo());
            tableData.add(oneRow);
        }
            
            session.getTransaction().commit();
        } catch (HibernateException he) {
            he.printStackTrace();
        }
        
        return tableData;
    }    
    
    public boolean updateTable(String id) throws HibernateException{
        
        try{
        Session session = NovoHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query query = session.createQuery("select e.status from Emprestimos e where id = " + id);
        
        String s = String.valueOf(query.uniqueResult());
        String str = String.valueOf(s.charAt(s.length() - 1));
        
        query = session.createQuery("update Emprestimos set Status=:Status where id=:id");
        
        if (str.equals("1")){
            query.setParameter("Status", 0);
            query.setLong("id", Integer.valueOf(id));
        }
        else if (str.equals("0")){
            query.setParameter("Status", 1);
            query.setLong("id", Integer.valueOf(id));
        }
        
        query.executeUpdate();
        
        session.getTransaction().commit();
            
        }
        catch (QueryException qe){
           
            qe.printStackTrace();
            System.out.println("Erro: id não existe");
            return false;
        }
        
        return true;
    }
    
}
